package com.vgroup.flexfit.data;

public enum ListSource {
    diet, exercises
}
