 ![App_Icon-_1-_Fin-RGB_-_smol](https://user-images.githubusercontent.com/67993582/149269229-0f10dba1-eb0b-4875-900d-aef2d71784a7.png) 
				<div id="2a9ec669-3456-4a59-8007-8026324615e3" style="width:75%" class="column">
					<h2 id="929eecc1-af7f-4737-88f9-1addde5786ad" class="">Flex Fit - Fitness App (Android)</h2>
					<p id="93ed1197-a051-4b76-b165-06a3959f90ff" class="">Estimated Time : 250+ Hours</p>
					<p id="55bfd51d-e761-4f2c-9ba8-429943c8607d" class="">Forte : Mobile Development Android</p>
					<p id="93ed1197-a051-4b76-b165-06a3959f90ff" class="">SDLC Components : Designing, Technical Planning, Developing &amp; Testing</p>
	<p id="93ed1197-a051-4b76-b165-06a3959f90ff" class="">Figma File (iOS) : <a href="https://www.figma.com/proto/cD4uTrlCCUmxW79bsbjWOZ/FlexFit-Mobile-App?embed_host=notion&kind=&node-id=2%3A422&page-id=0%3A1&scaling=scale-down&viewport=241%2C48%2C0.13">Here</a></p>
	<p id="93ed1197-a051-4b76-b165-06a3959f90ff" class="">Figma File (Android) : <a href="#">Work In Progress</a></p>
		<p id="93ed1197-a051-4b76-b165-06a3959f90ff" class="">Planning : <a href="https://furtive-wood-f20.notion.site/Semester-4-Project-2943120fa02642c18498c99071eaf68c">Click Here</a></p>
		<p id="93ed1197-a051-4b76-b165-06a3959f90ff" class="">Assets : <a href="https://furtive-wood-f20.notion.site/fc8cb4275a2e486d9cc8d1bdacc95dad?v=9603b1f382ea44c6b01d97c73a2ce01a">Click Here</a></p>
				</div>

<div id="3e1927f5-fb95-4783-aacd-02277abda632" style="width:75%" class="column">

<h2 id="929eecc1-af7f-4737-88f9-1addde5786ad" class="">Authors</h2>

- [Vaishnav Vivek Prabhu](https://github.com/vaishnavvprabhu)
- [Vaishnavi Singh](https://github.com/singhvaishnavi25)
				</div>

